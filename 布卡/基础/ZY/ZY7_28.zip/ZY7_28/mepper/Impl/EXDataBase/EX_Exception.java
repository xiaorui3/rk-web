package 布卡.基础.ZY.ZY7_28.mepper.Impl.EXDataBase;

public class EX_Exception extends  Exception{
    public EX_Exception() {
        super();
    }
    public EX_Exception(String message) {
        super(message);
    }
    public EX_Exception(String message, Throwable cause) {
        super(message, cause);
    }
    public EX_Exception(Throwable cause) {
        super(cause);
    }
}
