package 布卡.基础.ZY.ZY7_28.service.Examination;

/**
 * @Author: 赵锐 github ---> xiaorui3
 * @CreateTime: 2025-07-28
 * @Description: 用户UI通用接口
 * @Version: 1.0
 */

public interface ExaminationUI_In {
    public abstract void start();
}
