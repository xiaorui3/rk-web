public class Test{
	public static void main(String[] args){
		byte a = 1;
		a=(byte)(a+2);
		System.out.println(a);
	}
}