package 布卡.基础.ZY.ZY8_02.哲学家爱吃饭;

public class 筷子 {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public 筷子(String name) {
        this.name = name;
    }
}
